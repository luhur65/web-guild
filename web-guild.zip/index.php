<?php


require_once 'assets/bg-img/bg-masthead.jpg';


/**
 * Configurasi Database :
 * Buka folder (config) ==> config.php
 *
 * Halaman Admin
 * Buka Folder (attr) ==> Folder (Admin)
 *
 * Halaman User
 * Buka Folder (attr) ==> Folder (User)
 *
 * Halaman Template Web
 * Buka Folder (attr) ==> Folder (temp)
 *
 * Sekian & TerimaKasih...........
 */
