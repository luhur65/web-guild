<div class="card col-sm-8 shadow mx-auto">
    <div class="card-body">
    <h3 class="h3 font-weight-bold text-primary">Log Activity</h3>
    <hr class="divider">
    <?php 

    // Membuka file log
    readfile('../log.txt');
    
    ?>
    </div>
</div>